﻿using System;
using System.Diagnostics;
using System.Threading;

namespace CC;

class Seka
{
    void seka()
    {
        double x1 = 0; //Pirmasis ssekos numeris
        double x2 = 1; //Antrasis sekos numeris
        double f = x1 + x2; //Treciasis sekos numeris

        while (f <= Math.Pow(10, 15))
        {
            f = x1 + x2; //Sukuriamas naujos sekos numeris
            x1 = x2; //Priskiriamas antrasis sekos numeris pirmajam
            x2 = f; //Naujasis sekos numeris antrajam
        }
        Console.WriteLine("Galutinis rezultatas: " + f); //Isvedimas
    }

    static void Main(string[] args)
    {
        Seka labas = new Seka();
        labas.seka();

        Stopwatch stopwatch = new Stopwatch();
 
        stopwatch.Start();
        Thread.Sleep(100);
        stopwatch.Stop();
 
        Console.WriteLine("Elapsed Time is {0} ms", stopwatch.ElapsedMilliseconds);
    }
}
