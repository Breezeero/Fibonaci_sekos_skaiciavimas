﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Klases
{
    class Seka
    {
        public void seka()
        {
            double x1 = 0; //Pirmasis ssekos numeris
            double x2 = 1; //Antrasis sekos numeris
            double f = x1 + x2; //Treciasis sekos numeris

            while (f <= Math.Pow(10, 15))
            {
                f = x1 + x2; //Sukuriamas naujos sekos numeris
                x1 = x2; //Priskiriamas antrasis sekos numeris pirmajam
                x2 = f; //Naujasis sekos numeris antrajam
            }
            Console.WriteLine("Galutinis rezultatas: " + f); //Isvedimas
        }
    }
}
