﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Klases
{
class testas 
{ 
    static void Main(string[] args)
    {
            Seka labas = new Seka(); //Sukuriamas naujas objektas sekai skaiciuoti
            labas.seka(); //Paleidziamas kodas

            Stopwatch stopwatch = new Stopwatch(); //Sukuriamas naujas objektas laikui

            stopwatch.Start(); //Pradedamas laiko skaiciavimas
            Thread.Sleep(100); //Daroma 100 ms pauze
            stopwatch.Stop(); //Sustabdomas laikas

            Console.WriteLine("Elapsed Time is {0} ms", stopwatch.ElapsedMilliseconds); //Laiko isvestis
    }

}
}